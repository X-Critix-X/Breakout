//
// Created by micro on 18/01/2024.
//
#include "Game.h"

//void menu_title;

/*{
  if (!font1.loadFromFile("Data/Fonts/open-sans/OpenSans-ExtraBold.ttf"))
  {
    std::cout << "font did not load \n";
  }
  std::cout << "font loaded \n";
  title_text.setString("BREAKOUT!!");
  title_text.setFont(font2);
  title_text.setCharacterSize(100);
  title_text.setFillColor(sf::Color(255, 255, 255, 128));

  title_text.setPosition(
    window.getSize().x / 2 - title_text.getGlobalBounds().width / 2,
    window.getSize().y / 2 - title_text.getGlobalBounds().height / 0.25);
};
 */